(()=>{var e={};e.id=320,e.ids=[320],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6948:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>l.a,__next_app__:()=>u,pages:()=>d,routeModule:()=>p,tree:()=>c});var r=s(65239),i=s(48088),a=s(88170),l=s.n(a),o=s(30893),n={};for(let e in o)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>o[e]);s.d(t,n);let c={children:["",{children:["(Routes)",{children:["blog",{children:["category",{children:["[slug]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,57035)),"C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\(Routes)\\blog\\category\\[slug]\\page.tsx"]}]},{}]},{}]},{}]},{forbidden:[()=>Promise.resolve().then(s.t.bind(s,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(s.t.bind(s,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,46055))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(s.bind(s,32007)),"C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\layout.tsx"],loading:[()=>Promise.resolve().then(s.bind(s,99766)),"C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\loading.tsx"],"not-found":[()=>Promise.resolve().then(s.bind(s,82366)),"C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\not-found.tsx"],forbidden:[()=>Promise.resolve().then(s.t.bind(s,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(s.t.bind(s,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,46055))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,d=["C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\(Routes)\\blog\\category\\[slug]\\page.tsx"],u={require:s,loadChunk:()=>Promise.resolve()},p=new r.AppPageRouteModule({definition:{kind:i.RouteKind.APP_PAGE,page:"/(Routes)/blog/category/[slug]/page",pathname:"/blog/category/[slug]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11723:e=>{"use strict";e.exports=require("querystring")},12412:e=>{"use strict";e.exports=require("assert")},15469:(e,t,s)=>{"use strict";s.d(t,{Q:()=>i});var r=s(6475);let i=(0,r.createServerReference)("7fbbb7e2c8a94fb21ea13584ba27f9fe5ea116330d",r.callServer,void 0,r.findSourceMapURL,"revalidateSyncTags")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},41171:(e,t,s)=>{Promise.resolve().then(s.bind(s,98715)),Promise.resolve().then(s.bind(s,84453)),Promise.resolve().then(s.bind(s,66112)),Promise.resolve().then(s.t.bind(s,85814,23)),Promise.resolve().then(s.t.bind(s,79167,23))},52648:(e,t,s)=>{"use strict";s.d(t,{i:()=>l});var r=s(99902),i=s(23777);let a=s.n(i)()(r.S);function l(e){return a.image(e)}},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},57035:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>c,dynamic:()=>n});var r=s(37413),i=s(27810),a=s(88202),l=s(52648),o=s(36162);let n="force-dynamic";async function c({params:e}){let t=await (0,a.vB)(e.slug),s=await (0,a.bW)(),n=await (0,a.n0)();return(0,r.jsx)("div",{children:t&&0!==t.length?(0,r.jsxs)("div",{children:[(0,r.jsx)("section",{className:"th-blog-wrapper space-top space-extra-bottom",children:(0,r.jsx)("div",{className:"container",children:(0,r.jsxs)("div",{className:"row",children:[(0,r.jsx)("div",{className:"col-xxl-8 col-lg-7",children:t.map(e=>(0,r.jsxs)("div",{className:"th-blog blog-single has-post-thumbnail",children:[(0,r.jsx)("div",{className:"blog-img",children:(0,r.jsx)("a",{href:`/blog/${e.slug.current}`,children:(0,r.jsx)("img",{src:(0,l.i)(e.mainImage).url()||"",alt:e.title||""})})}),(0,r.jsxs)("div",{className:"blog-content",children:[(0,r.jsxs)("div",{className:"blog-meta",children:[(0,r.jsxs)("a",{className:"author",href:`/blog/${e.slug.current}`,children:[(0,r.jsx)("i",{className:"fal fa-user"}),"By Mamigas"]}),(0,r.jsxs)("a",{href:`/blog/${e.slug.current}`,children:[(0,r.jsx)("i",{className:"fal fa-calendar"}),new Date(e.publishedAt).toLocaleDateString()||"Unknown"]})]}),(0,r.jsx)("h2",{className:"blog-title",children:(0,r.jsx)("a",{href:`/blog/${e.slug.current}`,children:e.title||""})}),(0,r.jsx)("p",{className:"blog-text",children:e.excerpt||""}),(0,r.jsx)("a",{href:`/blog/${e.slug.current}`,className:"th-btn btn-sm",children:"Read More"})]})]},e.slug.current))}),(0,r.jsx)("div",{className:"col-xxl-4 col-lg-5",children:(0,r.jsxs)("aside",{className:"sidebar-area",children:[(0,r.jsxs)("div",{className:"widget widget_categories",children:[(0,r.jsx)("h3",{className:"widget_title",children:"Categories"}),(0,r.jsx)("ul",{children:s.map(e=>(0,r.jsx)("li",{children:(0,r.jsx)("a",{href:`/blog/category/${e.slug.current}`,children:e.title.trim()||"No Category Title"})},e._id))})]}),(0,r.jsxs)("div",{className:"widget",children:[(0,r.jsx)("h3",{className:"widget_title",children:"Recent Posts"}),(0,r.jsx)("div",{className:"recent-post-wrap",children:n.map(e=>(0,r.jsxs)("div",{className:"recent-post",children:[(0,r.jsx)("div",{className:"media-img",children:(0,r.jsx)("a",{href:`/blog/${e.slug.current}`,children:(0,r.jsx)("img",{src:(0,l.i)(e.mainImage)?.url()||"",alt:e.title||""})})}),(0,r.jsxs)("div",{className:"media-body",children:[(0,r.jsx)("h4",{className:"post-title",children:(0,r.jsx)("a",{className:"text-inherit",href:`/blog/${e.slug.current}`,children:e.title||""})}),(0,r.jsx)("div",{className:"recent-post-meta",children:(0,r.jsxs)("a",{href:`/blog/${e.slug.current}`,children:[(0,r.jsx)("i",{className:"fal fa-calendar"}),new Date(e.publishedAt)?.toLocaleDateString()||""]})})]})]},e.slug.current))})]})]})})]})})}),(0,r.jsx)(o.default,{src:"/assets/js/main.js",strategy:"afterInteractive"})]}):(0,r.jsx)(i.A,{title:"No Blogs Found In This Category",subtitle:"No Blog's"})})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64731:(e,t,s)=>{Promise.resolve().then(s.bind(s,58481)),Promise.resolve().then(s.bind(s,46420)),Promise.resolve().then(s.bind(s,43946)),Promise.resolve().then(s.t.bind(s,4536,23)),Promise.resolve().then(s.t.bind(s,47429,23))},74075:e=>{"use strict";e.exports=require("zlib")},77598:e=>{"use strict";e.exports=require("node:crypto")},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},85433:(e,t,s)=>{"use strict";s.r(t),s.d(t,{"7f542f2ab60dd12c71a1cbfe9a8df506c34b2507ae":()=>r.L,"7f9abfdff0442737de27d8739f39f9339d1bbbd350":()=>i.q,"7fbbb7e2c8a94fb21ea13584ba27f9fe5ea116330d":()=>r.Q});var r=s(34360),i=s(95075)},88202:(e,t,s)=>{"use strict";s.d(t,{AS:()=>x,Fh:()=>f,g6:()=>p,vB:()=>b,bW:()=>m,n0:()=>h,TS:()=>g});var r=s(99902),i=s(98810);let a=(0,i.E)(`*[_type == "post"] | order(publishedAt desc) {
  title,
  slug,
  mainImage,
  excerpt,
  publishedAt,
  "categories": categories[]->title
}
`),l=(0,i.E)(`
  *[_type == "post" && slug.current == $slug][0]{
    title,
    slug,
    publishedAt,
    mainImage,
    body,
  }
  `),o=(0,i.E)(`*[_type == "post"] | order(publishedAt desc)[0...3] {
  title,
  slug,
  mainImage,
  publishedAt
}
`);(0,i.E)(`
    *[_type == "post" && references(*[_type == "category" && title == $category]._id)] {
      title,
      slug,
      mainImage,
      publishedAt
    }
  `);let n=(0,i.E)(`*[_type == "category"] | order(title asc) {
  _id,
  title,
  slug
}
`),c=(0,i.E)(`
  *[_type == "post" && $slug in categories[]->slug.current] | order(publishedAt desc) {
    title,
    slug,
    mainImage,
    excerpt,
    publishedAt,
    "categories": categories[]->title
  }
`),d=(0,i.E)(`*[_type == "product"]{
  _id,
  title,
  slug,
  description,
  price,
  stock,
  "imageUrl": image.asset->url,
  publishedAt,
  category->{
    _id,
    title
  }
} | order(publishedAt desc)`),u=(0,i.E)(`
  *[_type == "productCategory"]{
  _id,
  title,
  slug,
  description
} | order(title asc)
`);(0,i.E)(`
  *[_type == "product" && slug.current == $slug][0]{
  _id,
  title,
  slug,
  image,
  description,
  price,
  stock,
  publishedAt,
  "category": category->{
    _id,
    title
  }
}
`),(0,i.E)(`*[_type == "product" && category->slug.current == $categorySlug]{
  _id,
  title,
  slug,
  image,
  description,
  price,
  stock,
  publishedAt,
  "category": category->{
    _id,
    title,
    slug
  }
}
`);let p=async()=>await r.S.fetch(a),g=async e=>await r.S.fetch(l,{slug:e}),h=async()=>await r.S.fetch(o),m=async()=>await r.S.fetch(n),b=async e=>await r.S.fetch(c,{slug:e}),x=async()=>await r.S.fetch(d),f=async()=>await r.S.fetch(u)},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},99902:(e,t,s)=>{"use strict";s.d(t,{S:()=>r});let r=(0,s(25588).UU)({projectId:"xfohgy13",dataset:"production",apiVersion:"2025-05-27",useCdn:!0})}};var t=require("../../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[447,182,491,739,777,667],()=>s(6948));module.exports=r})();